#!/bin/bash
pandoc --template=plantilla.tex   Práctica\ de\ diseño\ de\ protocolos\ P2P.md -o Práctica\ de\ diseño\ de\ protocolos\ P2P.pdf
