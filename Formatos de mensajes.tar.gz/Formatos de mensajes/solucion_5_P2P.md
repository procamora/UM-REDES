
## 5.Contempla posibles situaciones de error que puedan surgir y diseña los correspondientes mensajes de error que creas oportunos.

Errores posibles:

1. Peer informa de ficheros que no tiene
2.
